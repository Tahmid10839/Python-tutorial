from setuptools import setup

setup(name = "Package",
version= 0.1,
description = "This is a description",
long_description = "This is a long description",
author = "Tahmid",
packages = ['Package'],
install_requires = [] )

