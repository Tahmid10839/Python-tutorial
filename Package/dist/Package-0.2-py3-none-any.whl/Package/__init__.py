class Fu:
    def __init__(self):
        print("This is constructor")

    def func(self,num):
        print("The number is:")
        return num
