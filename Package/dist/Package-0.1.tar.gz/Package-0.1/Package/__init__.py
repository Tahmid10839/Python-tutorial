
def func(num):
    print("The number is:")
    return num